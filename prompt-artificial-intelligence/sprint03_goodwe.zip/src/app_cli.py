"""Chat de linha de comando do agente GoodWe (Sprint 03)."""
import uuid
from goodwe_agente import construir_agente, responder

def main():
    app = construir_agente()
    sessao = f"cli-{uuid.uuid4().hex[:8]}"
    print("Assistente GoodWe (Sprint 03). Digite 'sair' para encerrar.\n")
    while True:
        try:
            pergunta = input("Voce: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if pergunta.lower() in {"sair", "exit", "quit"}:
            break
        if pergunta:
            print("\nAgente:", responder(app, pergunta, sessao), "\n")

if __name__ == "__main__":
    main()
