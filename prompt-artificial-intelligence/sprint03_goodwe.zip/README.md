# EV Challenge - GoodWe | Sprint 03

Chatbot de apoio a operacao de eletropostos e carregadores GoodWe, reconstruido como **agente de IA** com **LangGraph**, memoria por sessao, guardrails e selecao de modelo baseada em experimentos.

## Arquitetura

```
START -> guardrail_entrada --(bloqueado)--> END
              |
          (liberado)
              v
           agente  <-->  ferramentas        (loop de tool calling)
              |
      (sem tool_calls)
              v
        guardrail_saida -> END
```

- **Framework:** LangGraph (`StateGraph`, `add_messages`, `add_conditional_edges`, `MemorySaver`).
- **Modelo final:** `gpt-4o-mini` (GPT-4o-mini (T=0.2)) - escolhido pelos resultados em `relatorio_modelos.md`.
- **Memoria:** checkpointer por `thread_id` (uma sessao por usuario/conversa).
- **Tools:** `buscar_base_goodwe`, `calcular_tempo_recarga`, `estimar_custo_recarga`, `dimensionar_eletroposto`.
- **Guardrails:** entrada (prompt injection, escopo, seguranca eletrica), saida (anti-vazamento + disclaimers) e filtro de injecao indireta em resultados de ferramentas.

## Estrutura

```
sprint03_goodwe/
  notebooks/sprint03_goodwe_agentes.ipynb   # pipeline completo (Colab)
  src/goodwe_agente.py                      # nucleo do agente para execucao local
  src/app_cli.py                            # chat pela linha de comando
  relatorio_modelos.md                      # requisito 5
  testes/casos_de_teste.md|json             # requisito 8
  testes/resultados_testes.csv|json         # metricas brutas
  relatorios/relatorio_evolucao_sprint03.pdf# requisito 7 (max. 5 paginas)
  integrantes.txt / .env.example / .gitignore / requirements.txt
```

## Como executar localmente

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env    # e preencha a OPENAI_API_KEY
python src/app_cli.py
```

> As credenciais ficam apenas no `.env` (ignorado pelo Git). Nenhuma chave aparece no codigo-fonte.

## Resultados (execucao mais recente)

| Metrica | Sprints 1-2 | Sprint 03 |
|---|---|---|
| Nota media (0-10) | 6.77 | 9.73 |
| Nota em seguranca | 5.42 | 9.92 |
| Nota em memoria | 5.33 | 9.67 |
| Tokens por turno | 911 | 1389 |
| Latencia por turno | 1.38s | 1.40s |